# narrativa/admin.py

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin # Importante para seu Usuario customizado
from .models import Narrativa, Cena, Escolha, Questionario, Pergunta, Usuario

# Inline para Escolhas (aparece na página da Cena)
class EscolhaInline(admin.TabularInline):
    model = Escolha
    fk_name = 'cena_origem'
    extra = 1

# Inline para Perguntas (aparece na página do Questionario)
class PerguntaInline(admin.TabularInline):
    model = Pergunta
    fk_name = 'questionario'
    extra = 1

@admin.register(Cena)
class CenaAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'narrativa', 'conteudo_textual', 'video', 'imagem')
    list_filter = ('narrativa',)
    search_fields = ('titulo', 'conteudo_textual')
    inlines = [EscolhaInline]

@admin.register(Narrativa)
class NarrativaAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'categoria', 'data_criacao', 'cena_inicial')
    list_filter = ('categoria', 'data_criacao')
    search_fields = ('titulo', 'descricao')

@admin.register(Questionario)
class QuestionarioAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'cena_associada')
    search_fields = ('titulo',)
    inlines = [PerguntaInline]

# Registro do seu modelo de Usuário customizado com o UserAdmin padrão do Django
# Se você tiver um UsuarioAdmin mais personalizado, MANTENHA O SEU.
# Caso contrário, esta linha garante que seu Usuario seja gerenciado corretamente.
admin.site.register(Usuario, UserAdmin)

# Escolha e Pergunta são gerenciados via Inlines, não precisam de registro direto.