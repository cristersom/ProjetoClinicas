from django.shortcuts import render, redirect, reverse
from .models import Narrativa, Usuario
from .forms import CriarContaForm, FormHomepage
from django.views.generic import TemplateView, ListView, DetailView, FormView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin
# Create your views here.
class Homepage(FormView):
    template_name = "homepage.html"
    form_class = FormHomepage

    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('narrativa:narrativas')
        else:
            return super().get(request, *args, **kwargs)

    def get_success_url(self):
        email = self.request.POST.get("email")
        usuarios = Usuario.objects.filter(email=email)
        if usuarios:
            return reverse('narrativa:login')
        else:
            return reverse('narrativa:criarconta')

class Narrativas(LoginRequiredMixin, ListView):
    template_name = "narrativas.html"
    model = Narrativa
# object_list -> LIsta de itens do modelo

class Detalhes(LoginRequiredMixin, DetailView):
    template_name = "detalhes.html"
    model = Narrativa
# object -> 1 item do nosso modelo

    def get(self, request, *args, **kwargs):
        narrativa = self.get_object()
        narrativa.visualizacoes += 1
        narrativa.save()
        usuario = request.user
        usuario.narrativas_vistas.add(narrativa)
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(Detalhes, self).get_context_data(**kwargs)
        #self.get_object()
        relacionados = Narrativa.objects.filter(categoria=self.get_object().categoria)[0:5]
        context["relacionados"] = relacionados
        return context


class Pesquisa(LoginRequiredMixin, ListView):
    template_name = "pesquisa.html"
    model = Narrativa
    def get_queryset(self):
        termo_pesquisa = self.request.GET.get('query')
        if termo_pesquisa:
            object_list = self.model.objects.filter(titulo__icontains=termo_pesquisa)
            return object_list
        else:
            return None

class Perfil(LoginRequiredMixin, UpdateView):
    template_name = "perfil.html"
    model = Usuario
    fields = ['first_name', 'last_name', 'email']

    def get_success_url(self):
        return reverse('narrativa:narrativas')



class Criarconta(FormView):
    template_name = "criarconta.html"
    form_class = CriarContaForm

    def form_valid(self, form):
        form.save()
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('narrativa:login')


# --- NOVO: View para iniciar a jornada do paciente (Tarefa 10) ---
def iniciar_jornada_paciente(request, narrativa_id):
    # 1. Encontrar a Narrativa pelo ID
    narrativa = get_object_or_404(Narrativa, pk=narrativa_id)

    # 2. Encontrar a cena inicial desta narrativa
    if not narrativa.cena_inicial:
        # Se por algum motivo a narrativa não tiver uma cena inicial definida,
        # retornamos para a homepage ou exibimos uma mensagem de erro.
        # Por enquanto, vamos para a página de narrativas, mas isso pode ser ajustado.
        return redirect('narrativa:narrativas') # Ou crie um template de erro específico

    # 3. Redirecionar para a exibição da cena inicial.
    # Esta URL 'exibir_cena_paciente' será criada na Tarefa 11.
    return redirect('narrativa:exibir_cena_paciente', cena_id=narrativa.cena_inicial.id)

# ... (fim do seu arquivo views.py)





# def homepage(request):
# return render(request, "homepage.html")

# def narrativas (request):
# context = {}
# lista_narrativas = Narrativa.objects.all()
# context['lista_narrativas'] = lista_narrativas
#     return render(request, "narrativas.html", context)